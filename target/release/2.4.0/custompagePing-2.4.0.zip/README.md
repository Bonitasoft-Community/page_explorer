# page_ping
Demonstrate a Custom page with Html, AngularJS, customRESTAPI embeded
<img src="ScreenShotPing_1.jpg"/> 

<img src="ScreenShotPing_2.jpg"/> 

Demonstrate the BonitaEvent librairy, and the result
<img src="ScreenShotPing_3.jpg"/> 

Demonstrate the BonitaProperties librairy, and how to save a value in the Bonita Database
<img src="ScreenShotPing_4.jpg"/> 

And a example of Modal in the custom page
<img src="ScreenShotPing_5.jpg"/> 
